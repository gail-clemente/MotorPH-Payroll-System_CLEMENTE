
package payroll;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

//Code for updating the First name based on the user logged in using the UserID and EmployeeID
public class EmployeeDataHandler {

    public Employee fetchEmployeeDetails(String username) {
        int employeeID = getEmployeeIDForUser(username);
        // Fetch other details based on employeeID from your database
        // Replace with actual logic to fetch from the database
        String lastName = null;
        String firstName = null;
        Date birthday = null;
        String address = null;
        String phoneNum = null;
        String sssNum = null;
        String philhealthNum = null;
        String pagibigNum = null;
        String tinNum = null;

        // Return an Employee instance
        return new Employee(employeeID, lastName, firstName, birthday, address, phoneNum, sssNum, philhealthNum, pagibigNum, tinNum);
    }


    public String getFirstNameForUser(String username) {
    try {
        MyConnection myConnection = MyConnection.getInstance();
        Connection connection = myConnection.connect();

        if (connection != null) {
            String selectQuery = "SELECT ed.First_Name FROM login l " +
                    "JOIN employee_details ed ON l.EmployeeID = ed.EmployeeID " +
                    "WHERE l.username = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery)) {
                preparedStatement.setString(1, username);

                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    return resultSet.getString("First_Name");
                } else {
                    // Handle the case where the username is not found
                    return "User not found";
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle the SQL exception
        return "Error retrieving first name";
    }

    return ""; // Default value or handle error appropriately
}

    
    private void updateFirstNameFromDatabase(String username, JLabel lblEmployeeName) {
    try {
        MyConnection myConnection = MyConnection.getInstance();
        Connection connection = myConnection.connect();

        if (connection != null) {
            String selectQuery = "SELECT ed.First_Name FROM login l " +
                    "JOIN employee_details ed ON l.EmployeeID = ed.EmployeeID " +
                    "WHERE l.username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery)) {
                preparedStatement.setString(1, username);

                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    lblEmployeeName.setText(resultSet.getString("First_Name") + "!");
                } else {
                    JOptionPane.showMessageDialog(null, "Employee not found.");
                }
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error retrieving employee details: " + ex.getMessage());
    }
}


    private int getEmployeeIDForUser(String username) {
    try {
        MyConnection myConnection = MyConnection.getInstance();
        Connection connection = myConnection.connect();

        if (connection != null) {
            String selectQuery = "SELECT EmployeeID FROM login WHERE username = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery)) {
                preparedStatement.setString(1, username);

                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    return resultSet.getInt("EmployeeID");
                } else {
                    // Handle the case where the user ID is not found
                    return -1; // or throw an exception
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle the SQL exception
    }

    return -1; // Default value or handle error appropriately
}

}